<?php
session_start();



require_once('header.php');
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Modifier les détails du livre</h2>


<?php require_once('footer.php'); ?>