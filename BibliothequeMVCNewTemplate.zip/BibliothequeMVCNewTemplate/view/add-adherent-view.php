<div class="container mt-3">
    <h2>Ajouter un adhérent</h2>
    <form method='post' action='add-adherent-action'>
        <input type='text' name='lastName' placeholder='T.'>
        <input type='text' name='name' placeholder='Cédric'>
        <input type='number' name='id' placeholder='1'>
        <input type='submit' name='add_adherent' value='Add'>
    </form>
</div>