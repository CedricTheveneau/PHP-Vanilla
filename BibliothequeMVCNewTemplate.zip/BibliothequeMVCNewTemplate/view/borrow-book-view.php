<div class="container mt-3">
    <h2>Emprunter un livre</h2>
    <form method='post' action='add-book-action'>
        <input type='text' name='title' placeholder='SHY'>
        <input type='text' name='author' placeholder='Bukimi Miki'>
        <input type='number' name='isbn' placeholder='12345'>
        <input type='number' name='pageCount' placeholder='254'>
        <input type='submit' name='add_book' value='Add'>
    </form>
</div>